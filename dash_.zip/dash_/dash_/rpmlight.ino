 // Button 2: Reset LEDs
  if (digitalRead(BUTTON2_PIN) == LOW) {
    resetLEDs = !resetLEDs;  // Toggle reset mode
    delay(200);  // Debounce delay
  }
}

// Function to make the top two red LEDs blink
void blinkTopRedLEDs() {
  unsigned long currentTime = millis();
  
  if (currentTime - lastBlinkTime >= 75) {  // Blink every 75 ms
    static bool ledsOn = false;

    if (ledsOn) {
      // Turn off the top two red LEDs
      strip.setPixelColor(7, strip.Color(0, 0, 0));  // 2nd Red LED
      strip.setPixelColor(8, strip.Color(0, 0, 0));  // 3rd Red LED
    } else {
      // Turn on the top two red LEDs
      strip.setPixelColor(7, strip.Color(255, 0, 0));  // 2nd Red LED
      strip.setPixelColor(8, strip.Color(255, 0, 0));  // 3rd Red LED
    }

    ledsOn = !ledsOn;  // Toggle LED state
    strip.show();  // Update the LED strip
    lastBlinkTime = currentTime;  // Reset the last blink time
  }
}

// Function to create a boot-up animation using the same colors from the RPM thresholds
void bootUpAnimation() {
  // Sweep through each LED and set it to the appropriate color
  setLEDColor(0, 0, 255, 255, 0, brightness);  // Yellow
  strip.show();
  delay(100);

  setLEDColor(1, 1, 204, 204, 0, brightness);  // Dark Yellow
  strip.show();
  delay(100);

  setLEDColor(2, 3, 255, 165, 0, brightness);  // Orange
  strip.show();
  delay(100);

  setLEDColor(4, 5, 255, 69, 0, brightness);   // Blood Orange
  strip.show();
  delay(100);

  setLEDColor(6, 6, 255, 0, 0, brightness);    // Red 1
  strip.show();
  delay(100);

  setLEDColor(7, 7, 255, 0, 0, brightness);    // Red 2
  strip.show();
  delay(100);

  setLEDColor(8, 8, 255, 0, 0, brightness);    // Red 3
  strip.show();
  delay(100);

  // Clear the strip after the animation
  strip.clear();
  strip.show();
}
